import React,{useState} from 'react'
import {Link} from 'react-router-dom';
import '../styles/Home.css';
import Dropdown from '../components/Dropdown';






function Home() {

  const [openLinks, setOpenLinks ] = useState(false);

  const toggleNavbar = () => {
    setOpenLinks(!openLinks);
  }
  return (
    <div className='Home'>
      <div className="headerContainer">

    
      
        <h1>FUTURE CAPITALS</h1>
        <p>It's time to INVEST in your future</p>
        <Link to="/">
          <div className='searchbar'>
          <input type="text" id="myInput" placeholder='Search by ISIN'></input>
          <div className='Searchbutton'>
          <Link to="/searchbyISIN"> Search </Link></div>
        
        <button onClick={toggleNavbar}></button>
        </div>
       

        <div>
          <Dropdown/>

        </div>
        
        
        </Link>
        </div>
      </div>
    
  );
}

export default Home;
