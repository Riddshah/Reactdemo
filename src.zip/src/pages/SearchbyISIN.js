import React from 'react'
import '../styles/SearchbyISIN.css';
function SearchbyISIN() {
  return (
    <div>
      
      <div className="App">
      <table>
        <tr>
          <th>Symbol</th>
          <th>Name of the company</th>
          <th>Series</th>
          <th>Date of listing</th>
          <th>Paidup value</th>
          <th>Market list</th>
          <th>ISIN</th>
          <th>Face value</th>
          <th>Sector</th>
          <th>Industry</th>
          <th>Exchange</th>
          <th>Currency</th>
          <th>Price</th>
          <th>Last update by</th>
          <th>Last updated</th>
        </tr>
       
      </table>
    </div>
    </div>
  )
}

export default SearchbyISIN
