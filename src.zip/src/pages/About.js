import React from 'react'
import '../styles/About.css'

function About() {
  return (
    <div className='about'>
        <div className='aboutTop'>
        <h1>
                &nbsp;&nbsp;&nbsp;&nbsp;ABOUT US
                </h1><br></br>
                <br></br>
                <br></br>
               
            
        </div>
        <div className='aboutBottom'>
        <p>“FUTURE CAPITALS” offers a comprehensive and<br></br> innovative product and service offerings
                     delivered <br></br>through a vertically-integrated business model<br></br> supported by a robust risk
                      management system framework.</p><br></br>
                      <br></br>       
                      <p>Email:futurecapitals@gmail.com
                    
                      <br></br>toll freeno:7827499498</p>
                
            
        </div>
      
    </div>
  )
}

export default About
